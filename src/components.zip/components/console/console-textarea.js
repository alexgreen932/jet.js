// import { render } from "vue";
// import { ops, actual, shot } from "../../app/data/store";

jet({
  name: "console-textarea",
  data: {
    // ops,
    // actual,
    // shot,
    prosseced_data:null,
  },

  tpl: html`
    <div class="console-inner console-textarea">
      <h3>{title}</h3>
      <textarea class="console-textarea-field">
      {prosseced_data}
      </textarea>
    </div>
  `,
  methods: {
    addValue() {
      this.arr.push(this.val);
      //   this.arr.push('"' + this.val + '"');
    },
  },
  mount(){
    if (this.item ==='current_page') {
        this.prosseced_data = JSON.stringify(this.actual.page);
        
    }
    this.render();
  }
});
