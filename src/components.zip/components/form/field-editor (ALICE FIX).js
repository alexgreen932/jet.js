jet({
  name: "field-editor",

  data: {
    rows: 8,
    cols: 20,
    mode: "editor", // editor | text

    // simple link popup
    show_link_popup: false,
    link_text: "",
    link_url: "",

    // saved selection for link dialog
    saved_range: null,
    saved_text: ""
  },

  tpl: html`
    <div j-if="mode=='editor'" class="editor-all-wrap">
      <div class="editor-toolbar jc-b">
        <div class="d-icons">
          <!-- Undo / Redo -->
          <button type="button" title="Undo" on-click="command('undo')">
            <i class="fa-solid fa-rotate-left"></i>
          </button>
          <button type="button" title="Redo" on-click="command('redo')">
            <i class="fa-solid fa-rotate-right"></i>
          </button>

          <!-- Text styles -->
          <button type="button" title="Bold" on-click="command('bold')">
            <b>B</b>
          </button>
          <button type="button" title="Italic" on-click="command('italic')">
            <i>I</i>
          </button>
          <button
            type="button"
            title="Underline"
            on-click="command('underline')"
          >
            <u>U</u>
          </button>

          <!-- Lists -->
          <button
            type="button"
            title="Ordered list"
            on-click="command('insertOrderedList')"
          >
            <i class="fa-solid fa-list-ol"></i>
          </button>
          <button
            type="button"
            title="Unordered list"
            on-click="command('insertUnorderedList')"
          >
            <i class="fa-solid fa-list-ul"></i>
          </button>

          <!-- Align -->
          <button
            type="button"
            title="Align left"
            on-click="command('justifyLeft')"
          >
            <i class="fa-solid fa-align-left"></i>
          </button>
          <button
            type="button"
            title="Align center"
            on-click="command('justifyCenter')"
          >
            <i class="fa-solid fa-align-center"></i>
          </button>
          <button
            type="button"
            title="Align right"
            on-click="command('justifyRight')"
          >
            <i class="fa-solid fa-align-right"></i>
          </button>
          <button
            type="button"
            title="Justify"
            on-click="command('justifyFull')"
          >
            <i class="fa-solid fa-align-justify"></i>
          </button>

          <!-- Link -->
          <button type="button" title="Insert link" on-click="openLinkPopup()">
            <i class="fa-solid fa-link"></i>
          </button>
          <button
            type="button"
            title="Remove link"
            on-click="command('unlink')"
          >
            <i class="fa-solid fa-link-slash"></i>
          </button>

          <!-- Remove formatting -->
          <button
            type="button"
            title="Remove formatting"
            on-click="command('removeFormat')"
          >
            <i class="fa-solid fa-eraser"></i>
          </button>
        </div>

        <!-- Switch mode -->
        <div class="d-icons">
          <button j-if="mode=='editor'" type="button" on-click="toggleMode()">
            <i class="fa-solid fa-code"></i>
            <span>{ __('Text') }</span>
          </button>
        </div>
      </div>
      <div
        class="inline-field"
        contenteditable="true"
        on-input="editorValue()"
        on-blur="editorValue()"
      ></div>
      <!-- Link popup -->
      <div
        j-if="show_link_popup"
        class="link-popup-overlay"
        style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center;"
      >
        <div
          style="background: white; padding: 20px; border-radius: 8px; min-width: 300px;"
        >
          <h4 style="margin-top: 0;">Вставить ссылку</h4>
          <div style="margin-bottom: 10px;">
            <label>Текст ссылки:</label>
            <input
              type="text"
              value="{link_text}"
              on-input="link_text = $event.target.value"
              style="width: 100%; padding: 5px; margin-top: 5px;"
            />
          </div>
          <div style="margin-bottom: 15px;">
            <label>URL:</label>
            <input
              type="text"
              value="{link_url}"
              on-input="link_url = '#'"
              placeholder="https://"
              style="width: 100%; padding: 5px; margin-top: 5px;"
            />
          </div>
          <div class="jc-e">
            <button
              type="button"
              on-click="cancelLink()"
              style="margin-right: 10px;"
            >
              Отмена
            </button>
            <button
              type="button"
              on-click="confirmLink()"
              style="background: #007bff; color: white;"
            >
              Вставить
            </button>
          </div>
        </div>
      </div>
    </div>

    <div j-if="mode=='text'" class="editor-wrap" j-if="mode=='text'">
      <div class="editor-toolbar jc-e">
        <button type="button" on-click="toggleMode()">
          <i class="fa-solid fa-pen"></i>
          <span>{ __('Editor') }</span>
        </button>
      </div>
      <textarea
        rows="{rows}"
        cols="{cols}"
        spellcheck="false"
        on-input="textValue()"
        on-blur="textValue()"
      ></textarea>
    </div>
  `,

  methods: {
    /* -----------------------------------------
       Small helpers
    ----------------------------------------- */

    getValue() {
      return this.obj?.[this.prop] ?? "";
    },

    setValue(v) {
      if (!this.obj || !this.prop) return;
      this.obj[this.prop] = v ?? "";
      this.dispatchEvent(new Event("jreact", { bubbles: true }));
    },

    // Read value from currently visible control
    pullCurrentValue() {
      if (this.mode === "editor") {
        const editor = this.querySelector(".inline-field");
        if (editor) this.setValue(editor.innerHTML);
      } else {
        const text = this.querySelector("textarea");
        if (text) this.setValue(text.value);
      }
    },

    // Write saved value into currently visible control
    syncValue() {
      const value = this.getValue();

      if (this.mode === "editor") {
        const editor = this.querySelector(".inline-field");
        if (editor && editor.innerHTML !== value) {
          editor.innerHTML = value || "<p></p>";
        }
      } else {
        const text = this.querySelector("textarea");
        if (text && text.value !== value) {
          text.value = value;
        }
      }
    },

    // Needed because j-if recreates DOM
    syncAfterRender() {
      requestAnimationFrame(() => {
        this.syncValue();
      });
    },

    focusEditor() {
      const editor = this.querySelector(".inline-field");
      if (editor) editor.focus();
    },

    /* -----------------------------------------
       Main editor logic
    ----------------------------------------- */

    command(command, value = null) {
      if (this.mode !== "editor") return;

      const editor = this.querySelector(".inline-field");
      if (!editor) return;

      editor.focus();

      try {
        document.execCommand(command, false, value);
      } catch (err) {
        console.warn("Command failed:", command, err);
      }

      this.editorValue();
      editor.focus();
    },

    toggleMode() {
      // save current mode content
      this.pullCurrentValue();

      // switch mode
      this.mode = this.mode === "editor" ? "text" : "editor";

      // wait until new DOM appears, then sync
      this.syncAfterRender();
    },

    editorValue() {
      const editor = this.querySelector(".inline-field");
      if (!editor) return;
      this.setValue(editor.innerHTML);
    },

    textValue() {
      const text = this.querySelector("textarea");
      if (!text) return;
      this.setValue(text.value);
    },

    //new methods

    saveSelection() {
      const editor = this.querySelector(".inline-field");
      const sel = window.getSelection();

      this.saved_range = null;
      this.saved_text = "";

      if (!editor || !sel || sel.rangeCount === 0) return;

      const range = sel.getRangeAt(0);

      // Only save selection if it is inside this editor
      if (!editor.contains(range.commonAncestorContainer)) return;

      this.saved_range = range.cloneRange();
      this.saved_text = sel.toString().trim();
    },

    restoreSelection() {
      const editor = this.querySelector(".inline-field");
      const sel = window.getSelection();

      if (!editor || !sel || !this.saved_range) return false;

      try {
        editor.focus();
        sel.removeAllRanges();
        sel.addRange(this.saved_range);
        return true;
      } catch (err) {
        console.warn("Failed to restore selection:", err);
        return false;
      }
    },

    insertLink(url, text = null) {
      if (this.mode !== "editor") return;

      const editor = this.querySelector(".inline-field");
      if (!editor) return;

      editor.focus();

      // Если есть сохранённое выделение, восстанавливаем его
      if (this.saved_range) {
        const restored = this.restoreSelection();
        if (!restored) {
          alert(
            "Не удалось восстановить выделение. Пожалуйста, выделите текст заново."
          );
          return;
        }
      } else {
        // Если ничего не выделено, просим выбрать текст
        alert("Пожалуйста, выделите текст для ссылки.");
        return;
      }

      const selection = window.getSelection();
      if (!selection || selection.rangeCount === 0) return;

      const range = selection.getRangeAt(0);
      const selectedText = selection.toString().trim();

      // Если текст не выбран, используем переданный текст или URL
      const linkText = text || selectedText || url;

      try {
        // Создаём ссылку вручную для большей надёжности
        const link = document.createElement("a");
        link.href = url;
        link.textContent = linkText;
        link.target = "_blank";
        link.rel = "noopener noreferrer";

        // Заменяем выделение на ссылку
        range.deleteContents();
        range.insertNode(link);

        // Очищаем выделение
        selection.removeAllRanges();
      } catch (err) {
        console.error("Failed to insert link:", err);
        alert("Не удалось вставить ссылку. Попробуйте ещё раз.");
      }

      this.editorValue();
      this.focusEditor();
    },

    openLinkPopup() {
      if (this.mode !== "editor") return;

      this.saveSelection();

      if (!this.saved_range || !this.saved_text) {
        alert("Пожалуйста, сначала выделите текст.");
        return;
      }

      // Показываем кастомное модальное окно для ввода ссылки
      this.show_link_popup = true;
      this.link_text = this.saved_text;
      this.link_url = "https://";
    },

    confirmLink() {
      const url = this.link_url.trim();
      const text = this.link_text.trim() || url;

      if (!url) {
        alert("Введите URL.");
        return;
      }

      const ok = /^(https?:\/\/|\/|#|mailto:|tel:)/i.test(url);
      if (!ok) {
        alert(
          "Неверный формат ссылки. Используйте: https://, /path, #anchor, mailto:, tel:"
        );
        return;
      }

      this.insertLink(url, text);

      // Закрываем popup
      this.cancelLink();
    },

    cancelLink() {
      this.show_link_popup = false;
      this.link_text = "";
      this.link_url = "";
    }
  },

  mount() {
    this.syncAfterRender();
  }
});
