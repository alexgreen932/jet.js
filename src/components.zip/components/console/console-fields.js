//example-


const test_data = {
  val: { val: "lorem", title: "Lorem Ipsum" },
  val2: [
    { val: "lorem", title: "Lorem Ipsum" },
    { val: "test", title: "Just Ipsum" }
  ],
  val3: "Test 3"
};

//

jet({
  name: "console-fields",
  data: {
    tabs: ["Show Data", "Add Data"],
    current_tab: "Show Data",
    obj: null,
    arr: ["val", "val2", "val3"],
    val: null,
    test_data,
    current_data: 0
  },
  _save: [
    ["arr", "state_obj_key_data"],
    ["obj", "state_obj_data"],
    ["current_data", "state_current_data_stater"]
  ],
  tpl: html`
    <div class="console-inner">
      <h3>Watch Show Data</h3>
      <ul class="console-tabs">
        <li j-for="tabs" on-click="current_tab=$[e]">[e]</li>
      </ul>
      <div
        class="console-tab-content jp ja-fade"
        j-if="current_tab=='Show Data'"
      >
        <select j-model="current_data">
          <option j-for="arr" value="$[e]">[e]</option>
        </select>
        <textarea>{proceesedValue()}</textarea>
      </div>
      <div
        class="console-tab-content jp ja-fade"
        j-if="current_tab=='Add Data'"
      >
        {arr}
        <label for="cons-obj">Object</label>
        <input id="cons-obj" j-model="obj" />
        <label for="cons-key">Key</label>
        <input id="cons-key" j-model="val" />
        <p class="but-blue" on-click="addValue()">Add</p>
        <!-- <p class="but-green" on-click="cleanStorage()">Clean</p> -->

        <div j-for="arr">
          [e] - <span class="j-click" on-click="removeItem([i])">x</span>
        </div>
      </div>
    </div>
    <div></div>
  `,
  methods: {
    addValue() {
      this.arr.push(this.val);
      //   this.arr.push('"' + this.val + '"');
    },
    // cleanStorage() {
    //   localStorage.removeItem("state_cos_stater");
    // },

    removeItem(i) {
      this.arr.splice(i, 1);
    },
    proceesedValue() {
      if (!this.obj) return;

      let prop = this[this.obj];
      console.log('prop:', prop);//output Proxy(Object) {val: {…}, val2: Array(2), val3: 'Test 3'}

      let ind = this.current_data;
      console.log('ind:', ind);//output "val"
      
      // let output = isStaticOrDynamic(obj, ind);

      //return JSON.stringify(output);//output undefined
      return JSON.stringify(this.test_data.val);//output correct json {"val":"lorem","title":"Lorem Ipsum"}
    }
  }
});
