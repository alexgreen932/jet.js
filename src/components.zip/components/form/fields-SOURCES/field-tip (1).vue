<template>
    <div class="tip-heading j-click ai-c g-25" @click="show = !show">
        <!-- <span v-if="!no_tip_tip_title">{{ $__('Tips') }} </span> -->
        <span v-if="tip_title">{{ tip_title }}</span>
        <i class="fa-solid fa-circle-exclamation"></i>
    </div>
    <TransitionGroup name="pop">
        <div v-if="show" class="admin-modal-bg" @click="show = !show">
            <div class="jc-e"><i class="fa-solid fa-xmark j-click"></i></div>
        </div>
        <div v-if="show" class="tips-box" @click="show = !show">
            <i class="fa-solid fa-xmark j-click float-r"></i>
            <div v-html="tipData()"></div>
        </div>
    </TransitionGroup>

</template>

<script>
import { tips } from './presets/tips.js';

export default {
    name: 'field-tip',
    props: ['modelValue', 'f', 'title', 'no_title'],
    data() {
        return {
            show: false,
            tip_title: this.$__('Tips'),
        };
    },
    methods: {
        tipData() {
            let output = tips[this.modelValue];
            // console.log('this.modelValue: ', this.modelValue);
            // console.log('tips----- ', tips);
            // console.log('output----- ', output);
            return output;
        }
    },
    // mounted() {
    //     console.log('this.title:', this.title);
    //     if (this.title || ) {
    //         this.tip_title = this.title;//overwrites default
    //     }
    //     console.log('this.tip_title:', this.tip_title);
    //     console.log('this.title:', this.title);
    // }
};
</script>
