//example-

const test_arr = {
  val: "Test 1",
  val2: "Test 2",
  val3: "Test 3"
};

// console.log('$.errors--------------', $.errors);

jet({
  name: "console-states",
  data: {
    tabs: ["States", "Set States"],
    current_tab: "States",
    obj: null,
    arr: ["val", "val2", "val3"],
    val: null,
    test_arr
  },
  _save: [["arr", "state_obj_key_stater"], ["obj", "state_obj_stater"]],
  tpl: html`
    <div class="console-inner">
      <h3>Watch States</h3>
      <ul class="console-tabs">
        <li j-for="tabs" on-click="current_tab=$[e]">[e]</li>
      </ul>
      <div class="console-tab-content jp ja-fade" j-if="current_tab=='States'">
        <div j-for="arr">
          [e] - {getVal('[e]')} <span class="j-click" on-click="removeItem([i])">x</span>
        </div>
      </div>
      <div
        class="console-tab-content jp ja-fade"
        j-if="current_tab=='Set States'"
      >
        {arr}
        <label for="cons-obj">Object</label>
        <input id="cons-obj" j-model="obj" prevent-update />
        <label for="cons-key">Key</label>
        <input id="cons-key" j-model="val" prevent-update />
        <p class="but-blue" on-click="addValue()">Add</p>
        <p class="but-green" on-click="cleanStorage()">Clean</p>
        <textarea j-model="arr"></textarea>
      </div>
    </div>
    <div></div>
  `,
  methods: {
    addValue() {
      this.arr.push(this.val);
      //   this.arr.push('"' + this.val + '"');
    },
    cleanStorage() {
      localStorage.removeItem("state_cos_stater");
    },
    getVal(e) {
    //   let prop = this.test_arr;
    if(!this.obj) return;
      let prop = this[this.obj];
    //   console.log("e-----", e);
    //   console.log("PROCESSED-----", prop[e]);
      return prop[e];
    },
    removeItem(i) {
      console.log("i:", i);
      this.arr.splice(i, 1);
    }
  }
});
