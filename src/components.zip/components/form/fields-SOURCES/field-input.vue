<template>
    <input
        :type="inputType()"
        :value="modelValue"
        @input="$emit('update:modelValue', $event.target.value)"
        :placeholder="placeholderM()"
    />
</template>

<script>
export default {
    name: 'field-input',
    props: ['modelValue', 'f'],
    data() {
        return {
            placeholder: 'Enter value...'
        };
    },
    methods: {
        placeholderM(){
            if (this.f.placeholder) {
                return this.f.placeholder;
            } else {
                return 'Enter value...';
            }
        },
        inputType() {
            // fallback to text if not provided
            return this.f.ops || 'text';
        }
    },
    mounted(){
        if (this.f.placeholder) {
            this.f.placeholder = this.f.placeholder;
        }
    }
};
</script>
