// import fields_presets
import { options } from "./helpers/options.js";

jet({
  name: "field-select",
  data:{
    show:false,
    ops:[],
  },
  tpl: html`
    <select id="field-{__jid}">
      <j-for data="ops">
         <option value="[v]">[t]</option>
      </j-for>
      
    </select>
  `,
  methods:{
    customOps(ops){
    
      let items = ops.split(',');
      
      let arr = [];
      items.forEach((it) => {
        let [key, val] = it.split(':');
        let object = {
          v:val.slice(1,-1),//no need quotes
          t:key.slice(1,-1),//no need quotes
        }
        arr.push(object);
      })
      this.ops = arr;
    }

  },
  mount() {
    const attr = this.getAttribute("s-ops") || "";
    
    if (attr.includes(',')) {//custom attrs
      this.customOps(attr);
    } else {//presets
      if (options[attr]) {
        this.ops = options[attr];
      }
    }
    this.render();//need to re render as ops is empty//todo j-load methods only if condition for example ops.length to do not use this.render()

    //method for all or for most fields
    this._form_model('select');
  }
});

