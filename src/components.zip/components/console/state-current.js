//example-

// import { ops } from "../../app/data/store.js";

// const test_arr = {
//     val: "Test 1",
//     val2: "Test 2",
//     val3: "Test 3"
// };

// console.log('$.errors--------------', $.errors);

jet({
  name: "state-current",
  data: {
    // ops,
    tabs: ["States", "Set States"],
    current_tab: "States",
    obj: null,
    arr: ["current_menu"],
    val: null,
    // test_arr,
    add_new: false,
    add_new_val: ""
  },
  _save: [["arr", "state_arr_ops_keys"]],
  tpl: html`
    <div class="console-inner">
      <h3 class="mt-2">States Current</h3>
      <button class="but-green" on-click="add_new=!add_new">New Watcher</button
      >
      <!-- add_new-{add_new} -->
      <div j-if="add_new" class="add_new_box">
        <input type="text" j-model="add_new_val" />
        <button class="but-blue" on-click="addValue()">New Watcher</button>
      </div>
      <div class="console-tab-content" j-if="current_tab=='States'">
        <div class="render_watched">
          <j-for data="arr">
            <div>
              <span class="j-click" on-click="removeItem([i])">x</span>
              <span class="d-title">[e]</span> - {getVal([$e])}
            </div>
          </j-for>
        </div>
      </div>
    </div>
    <div></div>
  `,
  methods: {
    addValue() {
      this.arr.push(this.add_new_val);
      //   this.arr.push('"' + this.val + '"');
    },
    cleanStorage() {
      localStorage.removeItem("state_cos_stater");
    },
    getVal(e) {
      console.log("e:", e);

      let prop = this.ops;
      console.log("prop:", prop);
      //   console.log("e-----", e);
      //   console.log("PROCESSED-----", prop[e]);
      return prop[e];
    },
    removeItem(i) {
      console.log("i:", i);
      this.arr.splice(i, 1);
    }
  }
});
