jet({
  name: "field-editor-i",
  data: {
    rows: 4,
    cols: 20,
    size: "min",
    mode: "editor",
    toolbar_on: false
    // mode: "text",
  },

  // no {val} inside
  tpl: html`
    <div class="editor-wrap" j-if="mode=='editor'">
      <!-- <div j-if="toolbar_on" class="editor-toolbar jc-b"> -->
      <div class="editor-toolbar jc-b">
        <div class="d-icons">
          <button on-click="command('bold')"><b>B</b></button>
          <button on-click="command('italic')"><i>I</i></button>
          <button on-click="command('underline')"><u>U</u></button>
          <button on-click="command('insertOrderedList')">
            <i class="fa-solid fa-list-ol"></i>
          </button>
          <button on-click="command('insertUnorderedList')">
            <i class="fa-solid fa-list-ul"></i>
          </button>
          <button on-click="command('justifyLeft')">
            <i class="fa-solid fa-align-left"></i>
          </button>
          <button on-click="command('justifyCenter')">
            <i class="fa-solid fa-align-center"></i>
          </button>
          <button on-click="command('justifyRight')">
            <i class="fa-solid fa-align-right"></i>
          </button>
        </div>

        <button j-if="mode=='editor'" type="button" on-click="toggleMode()">
          <i class="fa-solid fa-text-width"></i><span>{__('Text')}</span>
        </button>
      </div>
      <div
        class="inline-field"
        contenteditable="true"
        on-input="editorValue()"
        on-click="toolbar_on=true"
      >
        <p>Type anything...</p>
      </div>
    </div>
    <div j-if="mode=='text'" class="editor-wrap">
      <div class="editor-toolbar jc-e">
        <button on-click="toggleMode()">
          <i class="fa-solid fa-ellipsis"></i><span>{__('Editor')}</span>
        </button>
      </div>
      <textarea rows="{rows}" cols="{cols}" on-input="textValue()"></textarea>
    </div>
  `,

  methods: {
    command(command) {
      const editor = this.querySelector(".inline-field");
      // Волшебная функция, которая форматирует текст
      document.execCommand(command, false, null);
      // Возвращаем фокус в редактор, чтобы продолжить печатать
        editor.focus();
      console.log("editor.innerHTML:", editor.innerHTML);
    },
    toggleMode() {
      if (this.mode == "editor") {
        this.mode = "text";
      } else {
        this.mode = "editor";
      }
      this.this.syncValue();
    },
    //more ful version
    editorValue() {
      console.log("editorValue works");
      const editor = this.querySelector(".inline-field");
      let v = editor.innerHTML;
      this.obj[this.prop] = v;
      this.dispatchEvent(new Event("jreact", { bubbles: true }));
    },
    textValue() {
      console.log("editorValue works");
      const text = this.querySelector("textarea");
      console.log("text>>>>", text.value);
      this.obj[this.prop] = text.value;
      this.dispatchEvent(new Event("jreact", { bubbles: true }));
    },

    syncValue() {
      if (this.mode === "editor") {
        const text = this.querySelector(".inline-field");
        text.innerHTML = this.obj[this.prop];
      } else {
        const text = this.querySelector("textarea");
        text.value = this.obj[this.prop];
      }
    }

    // syncValue() {
    //   const el = this.querySelector("textarea");
    //   if (!el) return;
    //   el.value = this.obj?.[this.prop] ?? "";
    // }
  },

  mount() {
    this.syncValue();
  }
});
