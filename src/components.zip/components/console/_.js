
import updateNestedProperty from "./helpers/updateNestedProperty";


export default function installMethods(ctx, sources, reserved, tagName) {
  // sources = [obj1, obj2, obj3...]
  Object.entries(Object.assign({}, ...sources)).forEach(([name, fn]) => {
    if (typeof fn !== "function") return;

    if (reserved.includes(name)) {
      $.log(`Name "${name}" is Jet reserved name, choose another`, 2, tagName);
      return;
    }

    // avoid overwriting existing stuff unless you want to allow it
    if (name in ctx) {
      $.log(`Method "${name}" already exists on component, skipped`, 1, tagName);
      return;
    }

    ctx[name] = fn.bind(ctx);
  });
}
