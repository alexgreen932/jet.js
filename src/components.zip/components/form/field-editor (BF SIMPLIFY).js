jet({
  name: "field-editor",
  data: {
    isHTMLView: false, // iframe source toggle (when using iframe)
    // editorMode: true,
    textareaMode: false, // true => show plain <textarea>, false => iframe
    isMax: false, // true => fixed modal-like expanded editor
    syncingFromModel: false,
    doc: null,
    size: "min",
    mode: "editor"
  },
  // static: true,
  tpl: html`
    <!-- <input type="{inputType()}" /> -->
    <div class="{size}">
      <div class="j-editor-toolbar">
        <!-- Min/Max -->
        <button type="button" on-click="onToggleMax">
          <div j-if="size=='min'">
            <i class="fa-solid fa-maximize"></i><span>{__('Maximize')}</span>
          </div>

          <div j-if="size=='max'">
            <i class="fa-solid fa-minimize"></i><span>{__('Manify')}</span>
          </div>
        </button>


        <button type="button" on-click="onToggleTextareaMode()">
          <div j-if="mode=='editor'">
            <i class="fa-solid fa-text-width"></i><span>{__('Text')}</span>
          </div>
          <div j-if="mode=='text'">
            <i class="fa-solid fa-ellipsis"></i><span>{__('Editor')}</span>
          </div>
        </button>

        <!-- Iframe-only tools (hidden in textarea mode) -->
        <div j-if="mode=='editor'">
          <button
            type="button"
            on-click="onCmd('undo')"
            :disabled="disabled"
            title="Undo"
          >
            <i class="fa fa-undo"></i>
          </button>
          <button
            type="button"
            on-click="onCmd('redo')"
            :disabled="disabled"
            title="Redo"
          >
            <i class="fa fa-redo"></i>
          </button>

          <select
            class="j-heading-select"
            on-change="onFormatBlock($event.target.value)"
          >
            <option value="">Format block</option>
            <option value="H1">H1</option
            ><option value="H2">H2</option
            ><option value="H3">H3</option>
            <option value="H4">H4</option
            ><option value="H5">H5</option
            ><option value="H6">H6</option>
            <option value="P">Paragraph</option
            ><option value="BLOCKQUOTE">Quote</option>
          </select>

          <button
            type="button"
            on-click="onCmd('bold')"
            :disabled="disabled"
            title="Bold"
          >
            <i class="fa fa-bold"></i>
          </button>
          <button
            type="button"
            on-click="onCmd('italic')"
            :disabled="disabled"
            title="Italic"
          >
            <i class="fa fa-italic"></i>
          </button>
          <button
            type="button"
            on-click="onCmd('underline')"
            :disabled="disabled"
            title="Underline"
          >
            <i class="fa fa-underline"></i>
          </button>

          <button
            type="button"
            on-click="onCmd('insertUnorderedList')"
            :disabled="disabled"
            title="Bulleted list"
          >
            <i class="fa fa-list-ul"></i>
          </button>
          <button
            type="button"
            on-click="onCmd('insertOrderedList')"
            :disabled="disabled"
            title="Numbered list"
          >
            <i class="fa fa-list-ol"></i>
          </button>

          <button
            type="button"
            on-click="onCmd('justifyLeft')"
            :disabled="disabled"
            title="Align Left"
          >
            <i class="fa fa-align-left"></i>
          </button>
          <button
            type="button"
            on-click="onCmd('justifyCenter')"
            :disabled="disabled"
            title="Align Center"
          >
            <i class="fa fa-align-center"></i>
          </button>
          <button
            type="button"
            on-click="onCmd('justifyRight')"
            :disabled="disabled"
            title="Align Right"
          >
            <i class="fa fa-align-right"></i>
          </button>
          <button
            type="button"
            on-click="onCmd('justifyFull')"
            :disabled="disabled"
            title="Justify"
          >
            <i class="fa fa-align-justify"></i>
          </button>

          <button
            type="button"
            on-click="onCreateLink"
            :disabled="disabled"
            title="Create Link"
          >
            <i class="fa fa-link"></i>
          </button>
          <button
            type="button"
            on-click="onCmd('unlink')"
            :disabled="disabled"
            title="Unlink"
          >
            <i class="fa fa-unlink"></i>
          </button>

          <button
            type="button"
            on-click="onCmd('removeFormat')"
            :disabled="disabled"
            title="Remove formatting"
          >
            <i class="fa fa-eraser"></i>
          </button>

          <select
            ref="codeSelect"
            class="j-code-lang"
            @change="onInsertCode($event.target.value)"
            :disabled="disabled"
          >
            <option value="">Insert code block</option>
            <option value="language-html">HTML</option>
            <option value="language-css">CSS</option>
            <option value="language-js">JavaScript</option>
            <option value="language-php">PHP</option>
          </select>

          <!-- HTML source toggle INSIDE iframe -->
          <button
            type="button"
            class="j-toggle-html"
            on-click="onToggleIframeSource"
            :disabled="disabled"
            :title="isHTMLView ? 'Switch to WYSIWYG' : 'View HTML (iframe source)'"
          >
            🗎
          </button>
        </div>
      </div>

      <!-- Editor surface -->
      <iframe
        j-if="mode=='editor'"
        class="j-editor-iframe"
        style="width: '100%'; min-height: 300px; border: 1px solid #ccc; border-radius: 6px;"
      />

      <!-- Code (textarea) mode -->
      <textarea
        j-if="mode=='text'"
        :disabled="disabled"
        style="width: '100%'; min-height: 300px; border: 1px solid #ccc; border-radius: 6px;"
        :value="modelValue"
        @input="$emit('update:modelValue', $event.target.value); $emit('input', $event.target.value); $emit('change', $event.target.value)"
        spellcheck="false"
      />
    </div>
  `,
  methods: {
    inputType() {
      return this.ops ? this.ops : "text";
    },
    // --- Basic exec wrapper (kept for compatibility with your old behavior)
    safeExec(cmd, value = null) {
      try {
        if (!this.doc || this.textareaMode) return; // ignore in textarea mode
        this.doc.execCommand(cmd, false, value);
      } catch (e) {
        console.warn(`Command failed: ${cmd}`, e);
      }
    },

    // --- Iframe bootstrapping
    bootstrapIframe() {
      const iframe = this.$refs.iframe;
      iframe.srcdoc =
        '<!DOCTYPE html><html><head><meta charset="utf-8">' +
        "<style>html,body{margin:0;padding:10px;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;line-height:1.45} pre{overflow:auto;padding:10px;border:1px solid #ddd;border-radius:6px} blockquote{border-left:4px solid #ddd;margin:0;padding:4px 10px;color:#666}</style>" +
        "</head><body></body></html>";

      iframe.addEventListener(
        "load",
        () => {
          this.doc =
            iframe.contentDocument || iframe.contentWindow?.document || null;
          if (!this.doc) return;

          if (!this.disabled) this.doc.designMode = "on";
          this.doc.body.contentEditable = this.disabled ? "false" : "true";

          const start = this.modelValue || this.placeholder;
          this.setDocContent(start);

          // Sync on edits inside iframe
          this.doc.body.addEventListener("keyup", this.updateFromDoc, {
            passive: true
          });
          this.doc.body.addEventListener("input", this.updateFromDoc, {
            passive: true
          });
          this.doc.body.addEventListener("mouseup", this.updateFromDoc, {
            passive: true
          });
          this.doc.body.addEventListener("paste", () =>
            setTimeout(this.updateFromDoc, 0)
          );

          this.doc.body.focus();
        },
        { once: true }
      );
    },

    // --- Iframe content helpers
    setDocContent(html) {
      if (!this.doc) return;
      if (this.isHTMLView) {
        this.doc.body.textContent = (html || "").replace(/\r?\n/g, "\n");
      } else {
        this.doc.body.innerHTML = html;
      }
    },

    updateFromDoc() {
      if (!this.doc) return;
      const content = this.isHTMLView
        ? this.doc.body.textContent
        : this.doc.body.innerHTML;

      this.$emit("update:modelValue", content);
      this.$emit("input", content);
      this.$emit("change", content);
    },

    // --- Toolbar actions (iframe mode only)
    onCmd(cmd) {
      if (this.disabled || !this.doc || this.textareaMode) return;
      this.safeExec(cmd);
      this.doc.body.focus();
      this.updateFromDoc();
    },
    onFormatBlock(tag) {
      if (this.disabled || !this.doc || this.textareaMode) return;
      if (!tag) return;
      this.safeExec("formatBlock", tag);
      this.doc.body.focus();
      this.updateFromDoc();
      const sel = this.$refs.headingSelect;
      if (sel) sel.selectedIndex = 0;
    },
    onCreateLink() {
      if (this.disabled || !this.doc || this.textareaMode) return;
      const selection = this.doc.getSelection?.();
      if (!selection || selection.toString().trim() === "") {
        alert("Please select text to link.");
        return;
      }
      const url = prompt(
        "Enter a URL (can be #anchor or full link):",
        "https://"
      );
      if (!url || (!/^https?:\/\//.test(url) && !/^#/.test(url))) {
        alert("Invalid URL format. Use full link or #anchor.");
        return;
      }
      this.safeExec("createLink", url);
      const a = this.doc.querySelector('a[href="' + CSS.escape(url) + '"]');
      if (a) {
        a.target = "_blank";
        a.rel = "noopener noreferrer";
      }
      this.doc.body.focus();
      this.updateFromDoc();
    },
    onInsertCode(lang) {
      if (this.disabled || !this.doc || this.textareaMode) return;
      if (!lang) return;
      const html = `<pre><code class="${lang}">// your code here</code></pre><p></p>`;
      this.safeExec("insertHTML", html);
      this.doc.body.focus();
      const sel = this.$refs.codeSelect;
      if (sel) sel.selectedIndex = 0;
      this.updateFromDoc();
    },

    // --- View toggles
    onToggleIframeSource() {
      // Toggle "source" vs "rendered" INSIDE iframe (only when not in textarea mode)
      if (!this.doc || this.textareaMode) return;
      this.isHTMLView = !this.isHTMLView;
      if (this.isHTMLView) {
        this.doc.body.textContent = this.doc.body.innerHTML;
      } else {
        this.doc.body.innerHTML = this.doc.body.textContent;
      }
      this.updateFromDoc();
    },

    onToggleTextareaMode() {
      if (this.mode == "editor") {
        this.mode = "text";
      } else {
        this.mode = "editor";
      }
      // Switch between iframe WYSIWYG and plain textarea code mode.
      // Before switching away from iframe, sync content.
      if (!this.textareaMode && this.doc) {
        this.updateFromDoc();
      }
      this.textareaMode = !this.textareaMode;
      // When switching from textarea back to iframe: push latest model into iframe
      if (!this.textareaMode && this.doc) {
        this.setDocContent(this.modelValue || this.placeholder);
        this.doc.body.focus();
      }
    },

    onToggleMax() {
      // this.isMax = !this.isMax;
      if (this.size == "min") {
        this.size = "max";
      } else {
        this.size = "min";
      }
      // Optional: lock body scroll when maximized
      // document.documentElement.classList.toggle("j-editor-body-locked", this.isMax);
    }
  },
  mount() {
    const inp = this.querySelector("input");
    if (!inp) return;

    // initial value
    inp.value = this.obj?.[this.prop] ?? "";

    inp.addEventListener("input", e => {
      if (!this.obj || !this.prop) return;
      this.obj[this.prop] = e.target.value; // ✅ hits Proxy.set in parent data
      this._signal();

      //todo!!! TEMP solution send signal after delay for it do not jumping. It gives a delay

      // setTimeout(() => {
      //   let item = this.querySelector("input");
      //   let loader = this.querySelector(".save-loader ");
      //   if (!loader) {
      //     item.insertAdjacentHTML(
      //       "beforebegin",
      //       `<div class="save-loader"></div>`
      //     );
      //   }
      //   setTimeout(() => {
      //     this._signal();
      //   }, 600);
      // }, 3000);
    });
  }
});
