<template>
  <label :for="f.key">
    <input :id="f.key" type="checkbox" :checked="modelValue"
      @change="$emit('update:modelValue', $event.target.checked)">
    {{ f.title }}
    <inline-tip v-if="f.tip" :tip="f.tip" />
  </label>
</template>

<script>
import inlineTip from '../helpers/inlineTip.vue';
export default {
  name: 'field-checkbox',
  components: { inlineTip },
  props: ['modelValue', 'f'],
};
</script>
