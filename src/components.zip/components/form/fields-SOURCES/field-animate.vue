<template>
    <div class="fs-8 b-blue-l5 p-05 br-5 ta-c">{{ $__('Note: some effects looks not good below as required more space') }}</div>
    <div class="anim-wrap">
        <div class="d-group" v-for="(g, i) in list">
            <h3>- {{ g.t }} -</h3>
            <div class="d-group">
                <span v-for="(e, i) in g.l" :class="playAnim(e.v)" @click="$emit('update:modelValue', e.v)" @mouseenter="hovered = e.v">
                    {{ e.t }}
                </span>
            </div>
        </div>
    </div>
</template>

<script>
//version grouped
import inlineTip from '../helpers/inlineTip.vue';
export default {
    name: 'field-checkbox',
    components: { inlineTip },
    props: ['modelValue', 'f'],
    data() {
        return {
            hovered: null,
            list: [
                {
                    t: 'Fade',
                    l: [
                        { v: 'ja ja-fade-in', t: 'fade' },
                        { v: 'ja ja-fade-in-bottom', t: 'fade bottom' },
                        { v: 'ja ja-fade-in-bottom-s', t: 'fade bottom small' },
                        { v: 'ja ja-fade-in-top', t: 'fade top' },
                        { v: 'ja ja-fade-in-left', t: 'fade left' },
                        { v: 'ja ja-fade-in-right', t: 'fade right' },
                    ]
                },
                {
                    t: 'Scale',
                    l: [
                        { v: 'ja ja-scale-in-center', t: 'scale center' },
                        { v: 'ja ja-scale-in-hor-center', t: 'scale hor center' },
                        { v: 'ja ja-scale-in-ver-center ', t: 'scale ver cente' },
                        { v: 'ja ja-scale-in-ver-top', t: 'scale ver-top' },
                    ]
                },
                {
                    t: 'Focus',
                    l: [
                        { v: 'ja ja-text-focus-in', t: 'text focus' },
                        { v: 'ja ja-focus-in-expand', t: 'focus expand' },
                        { v: 'ja ja-focus-in-expand-fwd', t: 'focus expand fwd' },
                        { v: 'ja ja-focus-in-contract-bck', t: 'focus contract bck' },
                    ]
                },
                // {
                //     t: 'Swing',
                //     l: [

                //     ]
                // },
                

                {
                    t: 'Text Effects',
                    l: [
                        { v: 'ja ja-tracking-in-contract', t: 'contr act' },
                        { v: 'ja ja-tracking-in-expand', t: 'expand' },
                        { v: 'ja tracking-in-expand-fwd', t: 'expand fwd' },
                        { v: 'ja ja-tracking-in-expand-fwd-top', t: 'expand fwd top' },
                        { v: 'ja ja-tracking-in-expand-fwd-bottom', t: 'expand fwd bottom' },
                        { v: 'ja ja-tracking-in-contract-bck', t: 'contract bck' },
                        { v: 'ja ja-tracking-in-contract-bck-top', t: 'contract bck top' },
                        { v: 'ja ja-tracking-in-contract-bck-bottom', t: 'contract bck bottom' },
                        // { v: 'ja ', t: '' },
                    ]
                },

                // {
                //     t: 'Fade',
                //     l: [

                //     ]
                // },

            ]
        };
    },
    methods: {
        playAnim(v) {
            //not sure it's necessary // rm
            if (v == this.hovered) {
                let cls = v.replace('ja', '');
                return 'jp' + cls;
            }else{
                return null;
            }
        }
    },
};
</script>
