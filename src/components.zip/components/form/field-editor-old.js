jet({
  name: "field-editor",
  data: {
    rows: 4,
    cols: 20,
    size: "min",
    mode: "editor",
    // mode: "text",
  },

  // no {val} inside
  tpl: html`
    <div class="editor-settings">
      <button type="button" on-click="toggleSize">
        <div j-if="size=='min'">
          <i class="fa-solid fa-maximize"></i><span>{__('Maximize')}</span>
        </div>

        <div j-if="size=='max'">
          <i class="fa-solid fa-minimize"></i><span>{__('Manify')}</span>
        </div>
      </button>

      <button type="button" on-click="toggleMode()">
        <div j-if="mode=='editor'">
          <i class="fa-solid fa-text-width"></i><span>{__('Text')}</span>
        </div>
        <div j-if="mode=='text'">
          <i class="fa-solid fa-ellipsis"></i><span>{__('Editor')}</span>
        </div>
      </button>
      ---{mode}
    </div>
    <div j-if="mode=='editor'">
      <div class="editor-toolbar">
        <button on-click="command('bold')"><b>B</b></button>
        <button on-click="command('italic')"><i>I</i></button>
        <button on-click="command('underline')"><u>U</u></button>
        <button on-click="command('insertOrderedList')">
          <i class="fa-solid fa-list-ol"></i>
        </button>
        <button on-click="command('insertUnorderedList')">
          <i class="fa-solid fa-list-ul"></i>
        </button>
        <button on-click="command('justifyLeft')">
          <i class="fa-solid fa-align-left"></i>
        </button>
        <button on-click="command('justifyCenter')">
          <i class="fa-solid fa-align-center"></i>
        </button>
        <button on-click="command('justifyRight')">
          <i class="fa-solid fa-align-right"></i>
        </button>
      </div>
      <!-- Вот он, секретный ингредиент! -->
      <div id="jet-editor" contenteditable="true" on-input="editorValue()">
        <p>Type anything...</p>
      </div>
    </div>

    <textarea
      j-if="mode=='text'"
      rows="{rows}"
      cols="{cols}"
      on-input="textValue()"
    ></textarea>
  `,

  methods: {
    command(command) {
      const editor = document.getElementById("jet-editor");
      // Волшебная функция, которая форматирует текст
      document.execCommand(command, false, null);
      // Возвращаем фокус в редактор, чтобы продолжить печатать
      editor.focus();
      console.log("editor.innerHTML:", editor.innerHTML);
    },
    toggleMode() {
      if (this.mode == "editor") {
        this.mode = "text";
      } else {
        this.mode = "editor";
      }
      this.this.syncValue();
    },
    //more ful version
    editorValue() {
      console.log("editorValue works");
      const editor = document.getElementById("jet-editor");
      let v = editor.innerHTML;
      this.obj[this.prop] = v;
      this.dispatchEvent(new Event("jreact", { bubbles: true }));
    },
    textValue() {
      console.log("editorValue works");
      const text = this.querySelector("textarea");
      console.log("text>>>>", text.value);
      this.obj[this.prop] = text.value;
      this.dispatchEvent(new Event("jreact", { bubbles: true }));
    },
    toggleSize() {
      // this.isMax = !this.isMax;
      if (this.size == "min") {
        this.size = "max";
      } else {
        this.size = "min";
      }
    },
    //textarea ops
    fieldOps() {
      this.rows = this.ops?.[0] ?? 5;
      this.cols = this.ops?.[1] ?? 20;
    },

    syncValue() {
      if (this.mode === "editor") {
        const editor = document.getElementById("jet-editor");
        editor.innerHTML = this.obj[this.prop];
      } else {
        const text = this.querySelector("textarea");
        text.value = this.obj[this.prop];
      }
    }

    // syncValue() {
    //   const el = this.querySelector("textarea");
    //   if (!el) return;
    //   el.value = this.obj?.[this.prop] ?? "";
    // }
  },

  mount() {
    this.syncValue();
  }
});
