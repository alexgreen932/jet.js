// import { fields_presets } from "../app/data/preset_fields.js";
import "./form/field-input.js";
import "./form/field-checkbox.js";
import "./form/field-input-i.js";
import "./form/field-textarea.js";
import "./form/field-encoded.js";
import "./form/field-select.js";
import "./form/field-picker.js";
// import "./form/field-animate.js";
import "./form/field-range.js";
import "./form/field-media.js";
import "./form/field-editor.js";
import "./form/field-icons.js";

import "./form/field-richtext.js";
// import "./form/field-picker.js"; // if you have it

jet({
  name: "jet-form",

  data: {
    fields: [],
    obj: null // points to el[path] like el.st
  },
  tpl: html`
    <div class="jf-root form-box {cls}">
      <h3 class="form-title">{title}</h3>
      <!-- <span class="close-form" on-click="edit=!edit">Close</span> -->
      <div class="jet-form-fields">
        <j-for data="fields">
          <div class="form-field [type]">
            <label j-if="[$title]">[title]</label>
            ---[type]
            <j-tag
              type="[type]"
              prefix="field-"
              d-obj="obj"
              s-prop="[key]"
              s-ops="[ops]"
            ></j-tag>
          </div>
        </j-for>
      </div>
    </div>
  `,

  methods: {
    presetFields() {
      // obj must exist first
      if (!this.obj || typeof this.obj !== "object") {
        this.fields = [];
        return;
      }

      const keys = Object.keys(this.obj);
      const out = [];

      keys.forEach(k => {
        if (k === "ja") return; // skip internal
        if (fields_presets[k]) out.push(fields_presets[k]);
      });

      this.fields = out;
    }
  },

  mount() {
    //dev

    // el = section object, path = "st" etc
    if (!this.el || !this.path) return;

    // IMPORTANT: obj is a direct reference into your REAL data structure
    this.obj = this.el[this.path];

    // if presets mode is on, build fields from existing keys
    if (this.presets) this.presetFields();
    // this.render();
  }
});
