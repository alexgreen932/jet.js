jet({
  name: "console-popup",
  data: {
    list: [],
    cls: null
  },
  tpl: html`
    <div id="error-box" class="{'console-popup' mode}">
      <h3>{title}</h3>
      <ul class="log-items">
      <li j-for="list" j-html="$[e]"></li>
      </ul>
      <h3>
      
    </div>
  `,
  mount() {
    if (this.mode === "errors") {
      this.list = $.errors;
    }
  }
});
