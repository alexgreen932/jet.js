<script>
// Rich-text editor (iframe designMode) + simple textarea "code" mode.
// v-model is always the source of truth.
// Toolbar now has:
//  - 🗎 HTML/WYSIWYG toggle (switches between iframe and textarea)
//  - ⤢ Min/Max toggle (adds .j-editor--max on the root for modal-like full view)

export default {
  name: "FieldEditor",
  props: {
    modelValue: { type: String, default: "" },
    height: { type: [Number, String], default: 220 },
    placeholder: { type: String, default: "<p></p>" },
    disabled: { type: Boolean, default: false },
  },
  emits: ["update:modelValue", "change", "input"],
  data() {
    return {
      isHTMLView: false,   // iframe source toggle (when using iframe)
      isTextareaMode: false, // true => show plain <textarea>, false => iframe
      isMax: false,        // true => fixed modal-like expanded editor
      syncingFromModel: false,
      doc: null,
    };
  },
  mounted() {
    this.bootstrapIframe();
  },
  watch: {
    modelValue(newVal) {
      if (!this.doc || this.isTextareaMode) return;
      if (this.syncingFromModel) return;

      const current = this.isHTMLView
        ? this.doc.body.textContent
        : this.doc.body.innerHTML;

      if (current !== (newVal || "")) {
        this.setDocContent(newVal || this.placeholder);
      }
    },
    disabled(disable) {
      if (!this.doc) return;
      this.doc.designMode = disable ? "off" : "on";
      this.doc.body.contentEditable = disable ? "false" : "true";
    },
  },
  methods: {
    // --- Basic exec wrapper (kept for compatibility with your old behavior)
    safeExec(cmd, value = null) {
      try {
        if (!this.doc || this.isTextareaMode) return; // ignore in textarea mode
        this.doc.execCommand(cmd, false, value);
      } catch (e) {
        console.warn(`Command failed: ${cmd}`, e);
      }
    },

    // --- Iframe bootstrapping
    bootstrapIframe() {
      const iframe = this.$refs.iframe;
      iframe.srcdoc =
        '<!DOCTYPE html><html><head><meta charset="utf-8">' +
        '<style>html,body{margin:0;padding:10px;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;line-height:1.45} pre{overflow:auto;padding:10px;border:1px solid #ddd;border-radius:6px} blockquote{border-left:4px solid #ddd;margin:0;padding:4px 10px;color:#666}</style>' +
        "</head><body></body></html>";

      iframe.addEventListener("load", () => {
        this.doc =
          iframe.contentDocument || iframe.contentWindow?.document || null;
        if (!this.doc) return;

        if (!this.disabled) this.doc.designMode = "on";
        this.doc.body.contentEditable = this.disabled ? "false" : "true";

        const start = this.modelValue || this.placeholder;
        this.setDocContent(start);

        // Sync on edits inside iframe
        this.doc.body.addEventListener("keyup", this.updateFromDoc, { passive: true });
        this.doc.body.addEventListener("input", this.updateFromDoc, { passive: true });
        this.doc.body.addEventListener("mouseup", this.updateFromDoc, { passive: true });
        this.doc.body.addEventListener("paste", () => setTimeout(this.updateFromDoc, 0));

        this.doc.body.focus();
      }, { once: true });
    },

    // --- Iframe content helpers
    setDocContent(html) {
      if (!this.doc) return;
      if (this.isHTMLView) {
        this.doc.body.textContent = (html || "").replace(/\r?\n/g, "\n");
      } else {
        this.doc.body.innerHTML = html;
      }
    },

    updateFromDoc() {
      if (!this.doc) return;
      const content = this.isHTMLView
        ? this.doc.body.textContent
        : this.doc.body.innerHTML;

      this.$emit("update:modelValue", content);
      this.$emit("input", content);
      this.$emit("change", content);
    },

    // --- Toolbar actions (iframe mode only)
    onCmd(cmd) {
      if (this.disabled || !this.doc || this.isTextareaMode) return;
      this.safeExec(cmd);
      this.doc.body.focus();
      this.updateFromDoc();
    },
    onFormatBlock(tag) {
      if (this.disabled || !this.doc || this.isTextareaMode) return;
      if (!tag) return;
      this.safeExec("formatBlock", tag);
      this.doc.body.focus();
      this.updateFromDoc();
      const sel = this.$refs.headingSelect;
      if (sel) sel.selectedIndex = 0;
    },
    onCreateLink() {
      if (this.disabled || !this.doc || this.isTextareaMode) return;
      const selection = this.doc.getSelection?.();
      if (!selection || selection.toString().trim() === "") {
        alert("Please select text to link.");
        return;
      }
      const url = prompt("Enter a URL (can be #anchor or full link):", "https://");
      if (!url || (!/^https?:\/\//.test(url) && !/^#/.test(url))) {
        alert("Invalid URL format. Use full link or #anchor.");
        return;
      }
      this.safeExec("createLink", url);
      const a = this.doc.querySelector('a[href="' + CSS.escape(url) + '"]');
      if (a) { a.target = "_blank"; a.rel = "noopener noreferrer"; }
      this.doc.body.focus();
      this.updateFromDoc();
    },
    onInsertCode(lang) {
      if (this.disabled || !this.doc || this.isTextareaMode) return;
      if (!lang) return;
      const html = `<pre><code class="${lang}">// your code here</code></pre><p></p>`;
      this.safeExec("insertHTML", html);
      this.doc.body.focus();
      const sel = this.$refs.codeSelect;
      if (sel) sel.selectedIndex = 0;
      this.updateFromDoc();
    },

    // --- View toggles
    onToggleIframeSource() {
      // Toggle "source" vs "rendered" INSIDE iframe (only when not in textarea mode)
      if (!this.doc || this.isTextareaMode) return;
      this.isHTMLView = !this.isHTMLView;
      if (this.isHTMLView) {
        this.doc.body.textContent = this.doc.body.innerHTML;
      } else {
        this.doc.body.innerHTML = this.doc.body.textContent;
      }
      this.updateFromDoc();
    },

    onToggleTextareaMode() {
      // Switch between iframe WYSIWYG and plain textarea code mode.
      // Before switching away from iframe, sync content.
      if (!this.isTextareaMode && this.doc) {
        this.updateFromDoc();
      }
      this.isTextareaMode = !this.isTextareaMode;
      // When switching from textarea back to iframe: push latest model into iframe
      if (!this.isTextareaMode && this.doc) {
        this.setDocContent(this.modelValue || this.placeholder);
        this.doc.body.focus();
      }
    },

    onToggleMax() {
      this.isMax = !this.isMax;
      // Optional: lock body scroll when maximized
      document.documentElement.classList.toggle("j-editor-body-locked", this.isMax);
    },
  },
};
</script>

<template>
  <div
    class="j-editor"
    :class="{
      'is-disabled': disabled,
      'j-editor--max': isMax
    }"
  >
    <div class="j-editor-toolbar">
      <!-- Min/Max -->
      <button type="button" @click="onToggleMax" :title="isMax ? 'Minimize' : 'Maximize'">
        <i class="fa" :class="isMax ? 'fa-compress' : 'fa-expand'"></i>
      </button>

      <!-- Switch Editor <-> Code (textarea) -->
      <button type="button" @click="onToggleTextareaMode" :title="isTextareaMode ? 'Switch to Editor' : 'Switch to Code (textarea)'">
        <i class="fa" :class="isTextareaMode ? 'fa-keyboard-o' : 'fa-code'"></i>
      </button>

      <!-- Iframe-only tools (hidden in textarea mode) -->
      <template v-if="!isTextareaMode">
        <button type="button" @click="onCmd('undo')" :disabled="disabled" title="Undo"><i class="fa fa-undo" /></button>
        <button type="button" @click="onCmd('redo')" :disabled="disabled" title="Redo"><i class="fa fa-redo" /></button>

        <select ref="headingSelect" class="j-heading-select" @change="onFormatBlock($event.target.value)" :disabled="disabled">
          <option value="">Format block</option>
          <option value="H1">H1</option><option value="H2">H2</option><option value="H3">H3</option>
          <option value="H4">H4</option><option value="H5">H5</option><option value="H6">H6</option>
          <option value="P">Paragraph</option><option value="BLOCKQUOTE">Quote</option>
        </select>

        <button type="button" @click="onCmd('bold')" :disabled="disabled" title="Bold"><i class="fa fa-bold" /></button>
        <button type="button" @click="onCmd('italic')" :disabled="disabled" title="Italic"><i class="fa fa-italic" /></button>
        <button type="button" @click="onCmd('underline')" :disabled="disabled" title="Underline"><i class="fa fa-underline" /></button>

        <button type="button" @click="onCmd('insertUnorderedList')" :disabled="disabled" title="Bulleted list"><i class="fa fa-list-ul" /></button>
        <button type="button" @click="onCmd('insertOrderedList')" :disabled="disabled" title="Numbered list"><i class="fa fa-list-ol" /></button>

        <button type="button" @click="onCmd('justifyLeft')" :disabled="disabled" title="Align Left"><i class="fa fa-align-left" /></button>
        <button type="button" @click="onCmd('justifyCenter')" :disabled="disabled" title="Align Center"><i class="fa fa-align-center" /></button>
        <button type="button" @click="onCmd('justifyRight')" :disabled="disabled" title="Align Right"><i class="fa fa-align-right" /></button>
        <button type="button" @click="onCmd('justifyFull')" :disabled="disabled" title="Justify"><i class="fa fa-align-justify" /></button>

        <button type="button" @click="onCreateLink" :disabled="disabled" title="Create Link"><i class="fa fa-link" /></button>
        <button type="button" @click="onCmd('unlink')" :disabled="disabled" title="Unlink"><i class="fa fa-unlink" /></button>

        <button type="button" @click="onCmd('removeFormat')" :disabled="disabled" title="Remove formatting"><i class="fa fa-eraser" /></button>

        <select ref="codeSelect" class="j-code-lang" @change="onInsertCode($event.target.value)" :disabled="disabled">
          <option value="">Insert code block</option>
          <option value="language-html">HTML</option>
          <option value="language-css">CSS</option>
          <option value="language-js">JavaScript</option>
          <option value="language-php">PHP</option>
        </select>

        <!-- HTML source toggle INSIDE iframe -->
        <button type="button" class="j-toggle-html" @click="onToggleIframeSource" :disabled="disabled" :title="isHTMLView ? 'Switch to WYSIWYG' : 'View HTML (iframe source)'">
          🗎
        </button>
      </template>
    </div>

    <!-- Editor surface -->
    <iframe
      v-show="!isTextareaMode"
      ref="iframe"
      class="j-editor-iframe"
      :style="{ width: '100%', minHeight: (height + 'px'), border: '1px solid #ccc', borderRadius: '6px' }"
    />

    <!-- Code (textarea) mode -->
    <textarea
      v-show="isTextareaMode"
      :disabled="disabled"
      :style="{ width: '100%', minHeight: (height + 'px'), border: '1px solid #ccc', borderRadius: '6px', fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace' }"
      :value="modelValue"
      @input="$emit('update:modelValue', $event.target.value); $emit('input', $event.target.value); $emit('change', $event.target.value)"
      spellcheck="false"
    />
  </div>
</template>

<style scoped>
.j-editor { display: grid; gap: .5rem; position: relative; }
.j-editor-toolbar {
  display:flex; flex-wrap:wrap; gap:.4rem; align-items:center;
  background:#fff; border:1px solid #ddd; border-radius:8px; padding:.4rem;
}
.j-editor-toolbar button, .j-editor-toolbar select {
  border:1px solid #ddd; background:#f9f9f9; border-radius:6px;
  padding:.3rem .5rem; line-height:1; cursor:pointer;
}
.j-editor-toolbar button:disabled, .j-editor-toolbar select:disabled { opacity:.6; cursor:not-allowed; }
.j-editor.is-disabled { opacity:.8; }

/* Maximize: fixed modal-like view (one-class toggle) */
.j-editor--max {
  position: fixed;
  inset: 2rem;              /* margins from viewport edges */
  z-index: 9999;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-radius: 12px;
  box-shadow: 0 10px 40px rgba(0,0,0,.2);
  padding: 1rem;
  display: grid;
  grid-template-rows: auto 1fr;
}

/* Optional: lock scroll when maximized */
:global(html.j-editor-body-locked),
:global(body.j-editor-body-locked) {
  overflow: hidden;
}
</style>
