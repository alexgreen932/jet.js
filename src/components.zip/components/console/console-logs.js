//example-

jet({
  name: "console-logs",
  data: { logs: null },
  tpl: html`
    <div class="console-inner">
      <h3>{title}</h3>
      <ul class="log-items">
        <li j-for="logs" j-html="'[e]'"></li>
      </ul>
    </div>
    <div></div>
  `,
  mount() {
    switch (this.list) {
      case "proxy":
        this.logs = $.proxy;
        break;
      case "localstorage":
        this.logs = $.localstorage;
        break;

      default:
        break;
    }
    document.addEventListener("console_log", () => {
      // console.log("Console LOGS -  Event console_log catched!");
      this.render();
    });
    //check
    // document.addEventListener(
    //   "console_log",
    //   console.log("Console LOGS -  Event console_log catched!");
    // );
  },
  refresh: "console_log"
});
