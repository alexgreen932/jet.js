
// import { jet, $ } from "./jet.js";
import './console/console-logs.js';
import './console/console-states.js';
import './console/console-fields.js';
import './console/console-popup.js';
import './console/state-current.js';
import './console/console-textarea.js';

function jetConsole(aggs={}){
  document.body.insertAdjacentHTML('beforeend', '<jet-console></jet-console>');
}

// window.jetConsole = jetConsole();//for usins including <script src="comsole.js">
export { jetConsole };//for import

// 
setInterval(() => {
  // 
}, 1000);

jet({
  name: "jet-console",
  data: {
    buttons: [
      { t: "Current", icon: "fa-solid fa-calendar-days", v: "ops" },
      { t: "Carrent Page", icon: "", s:'CP', v: "current_page" },
    ],
    // current: null,
    current: "proxy",
    hasErrors:false,
    //lists
    // list_proxy: $.proxy //not set if direcly without in mount this.proxy = $.proxy;
  },  
  _save:[['current', 'key_console_current_tab']],
  methods: {
    doMargin() {
    
      
      if (this.current) {
      
        document.body.style.marginRight = "300px";
      } else {
        document.body.style.marginRight = 0;
      }
    }
  },
  tpl: html`
    <app-test></app-test>
    <div class="console-block">
      <div j-if="current" class="console-panel">
        <state-current j-if="current=='ops'"></state-current>
        <console-textarea j-if="current=='current_page'" s-title="Current Page" s-item="current_page"></console-textarea>
      </div>
      <div class="console-bar">
        <i class="fa-solid fa-xmark" on-click="current=null"></i>
        <j-for data="buttons">
        <i class="[icon]" on-click="current=[$v]">
        <span>[t]</span>[s]
        </i>
        </j-for>
      </div>
    </div>
    <console-popup j-if="hasErrors" s-mode="errors" title="Errors"></console-popup>
  `,
  mount() {
    this.doMargin();
    document.addEventListener("update_log", () => {    
      this.list_proxy = $.proxy;
      this.render();
      
    });
  document.addEventListener("jreact", () => {
      this.doMargin();
    });
    //popup activate 
    if($.errors.length) this.hasErrors = true;
    
  }
});
