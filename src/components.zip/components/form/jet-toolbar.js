jet({
  name: "jet-toolbar",

  // static true: no rerenders needed, it's a stable UI widget
  static: true,

  // template can use Jet events system (on-click) if you want
  tpl: html`
    <div class="jtbar">
      <button type="button" class="but-blue" on-click="toggleEdit()">Edit</button>
    </div>
  `,

  methods: {
    /**
     * Toggle edit mode on the target component
     */
    toggleEdit() {
      // _jet_target is assigned by core bridge (j_form_init)
      const target = this._jet_target;

      // safety check
      if (!target) return;

      // toggle boolean
      target.edit = !target.edit;

      // If your proxy emits jreact automatically, this is optional.
      // But safe to emit anyway (especially if edit is not in proxy).
      document.dispatchEvent(
        new CustomEvent("jreact", { detail: { path: "edit" } })
      );
    }
  }
});

