import __ from '../../../languages/index.js';

export const tips = {


    blank: __(``),
    style: __(`Style is all classes of whole element eg background, border-radius, animation etc`),
    els_style: __(`Element Style are styles for items inside of the element eg – icon color of list etc`),

    blank: `<p>${__('')}</p>`,
     
    e_infoboxes: `<p>${__('Set default background, color icon and heading color in “Element Style”. But its individual properties you can do in every box.')}</p><p>${__('Optionally you can add group background and box shadow')}</p>`,
    
    e_img: `${__('')}`,

    blocks: __(`<h3>What is a Block?</h3>
<p>A Block is a single section (row) of a page that contains different elements.
It’s part of a template — like one floor made from many smaller bricks(elements).</p>
<p>Think of it this way:</p>
<ol>
    <li>Element → a brick</li>
    <li>Block → a floor made of bricks</li>
    <li>Template → the whole building made of floors</li>
    <li>Theme → the style and roof + ground design of the building</li>
</ol>
<p>You can save any section you create as a Block —
just hover over it and click “Save as Block.”</p>`),
    infoboxes: __("1. If you use an icon mode, the icon of first element will be as default<br/> 2. You can do not use text, then it will be as nice buttons.<br/> 3. You can use HTML tags, for example use tag 'br' if you want your text will be like paragraphs etc."),
    pages: __(`<h3>The Page is the main unit of the Engine.</h3>
<p>
    It includes all content between the header and footer.  
    A page can have just one block or many blocks — for example, a landing page with several sections.  
    You can use any <strong>template</strong> as the base for a new page, and you can also save your own pages as templates.
</p>

<p>When you hover your mouse over any element or block, a toolbar will appear. You can use it to:</p>

<ul>
    <li><i class="fa-solid fa-pen-to-square"></i> Edit an element</li>
    <li><i class="fa-solid fa-chevron-up"></i><i class="fa-solid fa-chevron-down"></i> Move it up or down(left or right)</li>
    <li><i class="fa-solid fa-plus"></i> Add a new one</li>
    <li><i class="fa-solid fa-floppy-disk"></i> Save as a Pattern (for blocks only)</li>
    <li><i class="fa-solid fa-trash"></i> Delete it</li>
</ul>

<p>
    If a block toolbar covers an element’s toolbar,  
    use the <strong>Tree view</strong> on the left (make sure the menu is set to “Pages”).  
    This can happen when the element is very small or close to the left edge.
</p>
`),
    theme: __('Here you can customize you theme which includes - Page Style, Header and Footer.<br />You can also select preset theme or chose and download any from our catalog'),
    sec_title: __('Section Title is necessary for page menus only(see docs - "Page Menu")'),

    themes: __("<h3>What is a Jet Theme?</h3><p>A Jet Theme has three main parts of a page:</p><ol><li>Page itself</li><li>Header</li><li>Footer</li></ol><p>The main part of the page is called a template.<br>You can edit it in Pages or use any existing template as a base.</p><h3>What you can do:</h3><ol><li>Activate any theme to make it default.</li><li>Customize any theme as you wish.</li><li>It’s recommended to clone a theme before editing, to keep the original safe.</li><li>Cloning a theme creates your own version.</li><li>You can share your theme in our catalog.</li></ol><p>Our catalog is still small because we just started, but it will grow as the project develops.</p><p><strong>More information coming soon!</strong></p>"),
    group: __(`Element “Group” has no content, you should add element there. But it has some layout, see tab “Style”`),


};
