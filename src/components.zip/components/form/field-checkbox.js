jet({
  name: "field-checkbox",
  tpl: html`999
    <input id="{prop}" type="checkbox" />
  `,
  methods: {

  },
  mount() {
    const inp = this.querySelector("input");
    if (!inp) return;

    // initial value
    inp.value = this.obj?.[this.prop] ?? "";

    inp.addEventListener("input", e => {
      if (!this.obj || !this.prop) return;
      this.obj[this.prop] = e.target.value; // ✅ hits Proxy.set in parent data
    });
  }
});
