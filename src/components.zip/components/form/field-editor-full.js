jet({
  name: "field-editor",

  data: {
    rows: 10,
    cols: 20,
    size: "min",
    mode: "editor", // editor | text
    toolbar_on: false,

    // popup states
    show_link_popup: false,
    show_img_popup: false,
    show_demo_popup: false,

    // popup fields
    link_url: "",
    img_url: "",
    demo_preview: "",
    demo_code: "",
    demo_codepen: "",

    // block format select
    block_tag: ""
  },

  tpl: html`
    <div class="editor-all-wrap">
    ---{show_link_popup}

      <!-- =========================
           TOOLBAR
      ========================== -->
      <div class="editor-toolbar jc-b">
        <div class="d-icons">

          <!-- Undo / Redo -->
          <button type="button" title="Undo" on-click="command('undo')">
            <i class="fa-solid fa-rotate-left"></i>
          </button>
          <button type="button" title="Redo" on-click="command('redo')">
            <i class="fa-solid fa-rotate-right"></i>
          </button>

          <!-- Format block -->
          <select on-change="setBlock(this.value)">
            <option value="">{ __('Format') }</option>
            <option value="P">Paragraph</option>
            <option value="H1">H1</option>
            <option value="H2">H2</option>
            <option value="H3">H3</option>
            <option value="H4">H4</option>
            <option value="H5">H5</option>
            <option value="H6">H6</option>
            <option value="BLOCKQUOTE">Quote</option>
            <option value="PRE">Pre</option>
          </select>

          <!-- Text styles -->
          <button type="button" title="Bold" on-click="command('bold')"><b>B</b></button>
          <button type="button" title="Italic" on-click="command('italic')"><i>I</i></button>
          <button type="button" title="Underline" on-click="command('underline')"><u>U</u></button>

          <!-- Lists -->
          <button type="button" title="Ordered list" on-click="command('insertOrderedList')">
            <i class="fa-solid fa-list-ol"></i>
          </button>
          <button type="button" title="Unordered list" on-click="command('insertUnorderedList')">
            <i class="fa-solid fa-list-ul"></i>
          </button>

          <!-- Align -->
          <button type="button" title="Align left" on-click="command('justifyLeft')">
            <i class="fa-solid fa-align-left"></i>
          </button>
          <button type="button" title="Align center" on-click="command('justifyCenter')">
            <i class="fa-solid fa-align-center"></i>
          </button>
          <button type="button" title="Align right" on-click="command('justifyRight')">
            <i class="fa-solid fa-align-right"></i>
          </button>
          <button type="button" title="Justify" on-click="command('justifyFull')">
            <i class="fa-solid fa-align-justify"></i>
          </button>

          <!-- Remove formatting -->
          <button type="button" title="Remove formatting" on-click="command('removeFormat')">
            <i class="fa-solid fa-eraser"></i>
          </button>

          <!-- Link / unlink -->
          <button type="button" title="Insert link" on-click="openLinkPopup()">
            <i class="fa-solid fa-link"></i>
          </button>
          <button type="button" title="Remove link" on-click="command('unlink')">
            <i class="fa-solid fa-link-slash"></i>
          </button>

          <!-- Image -->
          <button type="button" title="Insert image" on-click="openImgPopup()">
            <i class="fa-regular fa-image"></i>
          </button>

          <!-- Demo block -->
          <button type="button" title="Insert demo block" on-click="openDemoPopup()">
            <i class="fa-solid fa-cube"></i>
            <span>{ __('Demo') }</span>
          </button>
        </div>

        <!-- Switch mode -->
        <div class="d-icons">
          <button j-if="mode=='editor'" type="button" on-click="toggleMode()">
            <i class="fa-solid fa-code"></i>
            <span>{ __('Text') }</span>
          </button>

          <button j-if="mode=='text'" type="button" on-click="toggleMode()">
            <i class="fa-solid fa-pen"></i>
            <span>{ __('Editor') }</span>
          </button>
        </div>
      </div>

      <!-- =========================
           EDITOR MODE
      ========================== -->
      <div class="editor-wrap" j-if="mode=='editor'">
        <div
          class="inline-field"
          contenteditable="true"
          on-input="editorValue()"
          on-blur="editorValue()"
          on-click="toolbar_on=true"
        ></div>
      </div>

      <!-- =========================
           TEXT MODE
      ========================== -->
      <div j-if="mode=='text'" class="editor-wrap">
        <textarea
          rows="{rows}"
          cols="{cols}"
          on-input="textValue()"
          on-blur="textValue()"
          spellcheck="false"
        ></textarea>
      </div>

      <!-- =========================
           LINK POPUP
      ========================== -->
      <div class="editor-popup-backdrop" j-if="show_link_popup">
        <div class="editor-popup">
          <div class="mb-05 fw-600">{ __('Insert link') }</div>
          <input
            type="text"
            placeholder="https://example.com or #anchor"
            value="{link_url}"
            on-input="link_url=this.value"
          />
          <div class="jc-e mt-05 g-05">
            <button type="button" on-click="closePopups()">{ __('Cancel') }</button>
            <button type="button" on-click="applyLink()">{ __('Apply') }</button>
          </div>
        </div>
      </div>

      <!-- =========================
           IMAGE POPUP
      ========================== -->
      <div class="editor-popup-backdrop" j-if="show_img_popup" on-click="closePopups()">
        <div class="editor-popup" on-click="stopBubble($event)">
          <div class="mb-05 fw-600">{ __('Insert image') }</div>
          <input
            type="text"
            placeholder="https://site.com/image.jpg"
            value="{img_url}"
            on-input="img_url=this.value"
          />
          <div class="jc-e mt-05 g-05">
            <button type="button" on-click="closePopups()">{ __('Cancel') }</button>
            <button type="button" on-click="applyImage()">{ __('Apply') }</button>
          </div>
        </div>
      </div>

      <!-- =========================
           DEMO BLOCK POPUP
      ========================== -->
      <div class="editor-popup-backdrop" j-if="show_demo_popup">
        <div class="editor-popup editor-popup-lg" on-click="stopBubble($event)">
          <div class="mb-05 fw-600">{ __('Insert demo block') }</div>

          <label class="d-block mb-05">{ __('Preview') }</label>
          <textarea rows="5" on-input="demo_preview=this.value">{demo_preview}</textarea>

          <label class="d-block mt-05 mb-05">{ __('Code') }</label>
          <textarea rows="5" on-input="demo_code=this.value">{demo_code}</textarea>

          <label class="d-block mt-05 mb-05">{ __('CodePen URL') }</label>
          <textarea rows="3" on-input="demo_codepen=this.value">{demo_codepen}</textarea>

          <div class="jc-e mt-05 g-05">
            <button type="button" on-click="closePopups()">{ __('Cancel') }</button>
            <button type="button" on-click="applyDemoBlock()">{ __('Insert') }</button>
          </div>
        </div>
      </div>

    </div>
  `,

  methods: {
    /* -----------------------------------------
       Small helpers
    ----------------------------------------- */

    // Stops popup inner click from closing popup backdrop
    stopBubble(e) {
      e.stopPropagation();
    },

    // Safe getter for current field value
    getValue() {
      return this.obj?.[this.prop] ?? "";
    },

    // Safe setter for current field value
    setValue(v) {
      if (!this.obj || !this.prop) return;
      this.obj[this.prop] = v ?? "";
      this.dispatchEvent(new Event("jreact", { bubbles: true }));
    },

    // Keep value in currently visible control BEFORE switching mode
    pullCurrentValue() {
      if (this.mode === "editor") {
        const editor = this.querySelector(".inline-field");
        if (editor) this.setValue(editor.innerHTML);
      } else {
        const text = this.querySelector("textarea");
        if (text) this.setValue(text.value);
      }
    },

    // Push stored value INTO currently visible control AFTER mode switched
    syncValue() {
      const value = this.getValue();

      if (this.mode === "editor") {
        const editor = this.querySelector(".inline-field");
        if (editor && editor.innerHTML !== value) {
          editor.innerHTML = value || "<p></p>";
        }
      } else {
        const text = this.querySelector("textarea");
        if (text && text.value !== value) {
          text.value = value;
        }
      }
    },

    // Because j-if recreates DOM, we wait one frame
    syncAfterRender() {
      requestAnimationFrame(() => {
        this.syncValue();
      });
    },

    focusEditor() {
      const editor = this.querySelector(".inline-field");
      if (editor) editor.focus();
    },

    encodeStatic(v) {
      return encodeURIComponent(v || "");
    },

    // Very small HTML escape for attributes that may contain quotes
    escapeAttr(v) {
      return String(v || "")
        .replace(/&/g, "&amp;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
    },

    /* -----------------------------------------
       Main editor logic
    ----------------------------------------- */

    command(command, value = null) {
      // Works only in contenteditable mode
      if (this.mode !== "editor") return;

      const editor = this.querySelector(".inline-field");
      if (!editor) return;

      editor.focus();

      try {
        document.execCommand(command, false, value);
      } catch (err) {
        console.warn("Command failed:", command, err);
      }

      this.editorValue();
      editor.focus();
    },

    setBlock(tag) {
      if (!tag) return;
      this.command("formatBlock", tag);
    },

    toggleMode() {
      // 1. save current visible value
      this.pullCurrentValue();

      // 2. switch mode
      this.mode = this.mode === "editor" ? "text" : "editor";

      // 3. after rerender sync into new DOM element
      this.syncAfterRender();
    },

    editorValue() {
      const editor = this.querySelector(".inline-field");
      if (!editor) return;
      this.setValue(editor.innerHTML);
    },

    textValue() {
      const text = this.querySelector("textarea");
      if (!text) return;
      this.setValue(text.value);
    },

    /* -----------------------------------------
       Link popup
    ----------------------------------------- */

    openLinkPopup() {
      this.show_link_popup = true;
      this.link_url = "";
    },

    applyLink() {
      const url = (this.link_url || "").trim();
      if (!url) return;

      // Allow full URL, relative URL, mailto, tel, anchor
      const ok =
        /^(https?:\/\/|\/|#|mailto:|tel:)/i.test(url);

      if (!ok) {
        alert("Invalid link. Use https://, /path, #anchor, mailto:, tel:");
        return;
      }

      this.command("createLink", url);
      // this.closePopups();
      this.show_link_popup=false;
    },

    /* -----------------------------------------
       Image popup
    ----------------------------------------- */

    openImgPopup() {
      this.show_img_popup = true;
      this.img_url = "";
    },

    applyImage() {
      const url = (this.img_url || "").trim();
      if (!url) return;

      // insertImage is inconsistent in some browsers,
      // so insertHTML is more predictable here
      const html = '<img src="' + this.escapeAttr(url) + '" alt="" />';
      this.command("insertHTML", html);
      this.closePopups();
    },

    /* -----------------------------------------
       Demo popup
    ----------------------------------------- */

    openDemoPopup() {
      this.show_demo_popup = true;
      this.demo_preview = "";
      this.demo_code = "";
      this.demo_codepen = "";
    },

    applyDemoBlock() {
      const preview = this.encodeStatic(this.demo_preview);
      const code = this.encodeStatic(this.demo_code);
      const codepen = this.encodeStatic(this.demo_codepen);

      // Add only attributes that have value
      let attrs = [];

      if (this.demo_preview.trim()) {
        attrs.push('s-preview="' + preview + '"');
      }

      if (this.demo_code.trim()) {
        attrs.push('s-code="' + code + '"');
      }

      if (this.demo_codepen.trim()) {
        attrs.push('s-codepen="' + codepen + '"');
      }

      const html = "<doc-demo " + attrs.join(" ") + "></doc-demo>";

      this.command("insertHTML", html);
      this.closePopups();
    },

    closePopups() {
      this.show_link_popup = false;
      this.show_img_popup = false;
      this.show_demo_popup = false;
    }
  },

  mount() {
    // Initial sync when component mounts
    this.syncAfterRender();
  }
});